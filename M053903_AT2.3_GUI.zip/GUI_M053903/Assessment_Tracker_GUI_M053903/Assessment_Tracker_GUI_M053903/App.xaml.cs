﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Assessment_Tracker_GUI_M053903
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
