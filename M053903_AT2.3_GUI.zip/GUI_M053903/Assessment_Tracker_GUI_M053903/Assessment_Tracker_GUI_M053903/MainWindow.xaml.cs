﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace AssessmentTrackerWpf
{
    /// <summary>
    /// Interactions for MainWindow.xaml.
    /// Adds functions for adding, searching, deleting,
    /// and displaying assessments in the tracker system.
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// File path used to store assessment data.
        /// </summary>
        private readonly string textFile = "results.txt";

        /// <summary>
        /// Collection of assessments displayed in the UI.
        /// </summary>
        private ObservableCollection<Assessment> _assessments;

        /// <summary>
        /// Constructor: Initialises the UI and loads assessment data.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            _assessments = new ObservableCollection<Assessment>(LoadResultsFromFile(textFile));
            RefreshViews();
        }

        // 
        // LOAD FILE
        // 

        /// <summary>
        /// Loads assessments from the results file.
        /// </summary>
        private List<Assessment> LoadResultsFromFile(string filePath)
        {
            var list = new List<Assessment>();
            if (!File.Exists(filePath)) return list;

            foreach (var line in File.ReadAllLines(filePath))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                var parts = line.Split('|');
                if (parts.Length >= 3 && DateTime.TryParse(parts[1], out var due))
                {
                    list.Add(new Assessment
                    {
                        Name = parts[0],
                        DueDate = due,
                        Result = parts[2]
                    });
                }
            }
            return list;
        }

        /// <summary>
        /// Saves all assessments to the results file.
        /// </summary>
        private void SaveResults()
        {
            var lines = _assessments.Select(a =>
                $"{a.Name}|{a.DueDate:dd/MM/yyyy}|{a.Result}|{a.Status}");

            File.WriteAllLines(textFile, lines);
        }

        // 
        // REFRESH DATA
        // 

        /// <summary>
        /// Updates the Current/Due and Completed assessment lists.
        /// </summary>
        private void RefreshViews()
        {
            dgCurrentDue.ItemsSource = _assessments
                .Where(a => a.Status == "Due" || a.Status == "Overdue")
                .OrderBy(a => a.DueDate)
                .ToList();

            dgCompleted.ItemsSource = _assessments
                .Where(a => a.Status == "Passed" || a.Status == "Failed")
                .OrderBy(a => a.DueDate)
                .ToList();
        }

        // 
        // ADD NEW ASSESSMENT
        // 

        /// <summary>
        /// Adds a new assessment to the table.
        /// </summary>
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Assessment name cannot be empty.");
                return;
            }

            if (dpDueDate.SelectedDate == null)
            {
                MessageBox.Show("Please select a due date.");
                return;
            }

            var resultItem = cmbResult.SelectedItem as ComboBoxItem;
            var resultText = resultItem?.Content?.ToString() ?? "N/A";

            var assessment = new Assessment
            {
                Name = txtName.Text.Trim(),
                DueDate = dpDueDate.SelectedDate.Value,
                Result = resultText
            };

            _assessments.Add(assessment);
            SaveResults();
            RefreshViews();

            txtName.Clear();
            dpDueDate.SelectedDate = null;
            cmbResult.SelectedIndex = 0;
        }

        // 
        // DELETE ASSESSMENT
        // 

        /// <summary>
        /// Deletes the selected assessment.
        /// </summary>
        private void DeleteAssessment_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.DataContext is Assessment assessment)
            {
                var confirm = MessageBox.Show(
                    $"Delete '{assessment.Name}'?",
                    "Confirm Delete",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (confirm == MessageBoxResult.Yes)
                {
                    _assessments.Remove(assessment);
                    SaveResults();
                    RefreshViews();
                }
            }
        }

        // 
        // SEQUENTIAL SEARCH
        // 

        /// <summary>
        /// Performs a sequential (linear) search for assessments.
        /// </summary>
        private List<Assessment> SequentialSearch(string term)
        {
            term = term.ToLower();
            var results = new List<Assessment>();

            foreach (var a in _assessments)
            {
                if (a.Name.ToLower().Contains(term))
                {
                    results.Add(a);
                }
            }

            return results;
        }

        // 
        // BINARY SEARCH
        // 

        /// <summary>
        /// Performs a binary search for an exact assessment name match.
        /// </summary>
        private Assessment BinarySearch(string term)
        {
            var sorted = _assessments.OrderBy(a => a.Name).ToList();
            int left = 0;
            int right = sorted.Count - 1;

            while (left <= right)
            {
                int mid = (left + right) / 2;
                int comparison = string.Compare(sorted[mid].Name, term, true);

                if (comparison == 0)
                    return sorted[mid];

                if (comparison < 0)
                    left = mid + 1;
                else
                    right = mid - 1;
            }

            return null;
        }

        // 
        // SEARCH BUTTON
        // 

        /// <summary>
        /// Executes both Sequential and Binary search and displays results.
        /// </summary>
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string term = txtSearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(term))
            {
                RefreshViews();
                return;
            }

            var seqResults = SequentialSearch(term);
            var binResult = BinarySearch(term);

            var finalResults = new List<Assessment>();

            if (binResult != null)
                finalResults.Add(binResult);

            foreach (var a in seqResults)
            {
                if (!finalResults.Contains(a))
                    finalResults.Add(a);
            }

            dgCurrentDue.ItemsSource = finalResults
                .Where(a => a.Status == "Due" || a.Status == "Overdue")
                .ToList();

            dgCompleted.ItemsSource = finalResults
                .Where(a => a.Status == "Passed" || a.Status == "Failed")
                .ToList();
        }

        // 
        // PLACEHOLDER HANDLERS
        // 

        /// <summary>
        /// Placeholders before data is input
        /// </summary>

        private void txtName_TextChanged(object sender, TextChangedEventArgs e)
        {
            txtNamePlaceholder.Visibility =
                string.IsNullOrWhiteSpace(txtName.Text)
                ? Visibility.Visible
                : Visibility.Hidden;
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            txtSearchPlaceholder.Visibility =
                string.IsNullOrWhiteSpace(txtSearch.Text)
                ? Visibility.Visible
                : Visibility.Hidden;
        }
    }

    // 
    // ASSESSMENT MODEL
    // 

    /// <summary>
    /// Represents a single assessment record.
    /// </summary>
    public class Assessment
    {
        /// <summary>
        /// Name of the assessment.
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Due date of the assessment.
        /// </summary>
        public DateTime DueDate { get; set; }

        /// <summary>
        /// Result (Pass, Fail, N/A).
        /// </summary>
        public string Result { get; set; } = "N/A";

        /// <summary>
        /// Status based on result and due date.
        /// </summary>
        public string Status
        {
            get
            {
                if (Result.Equals("Pass", StringComparison.OrdinalIgnoreCase))
                    return "Passed";

                if (Result.Equals("Fail", StringComparison.OrdinalIgnoreCase))
                    return "Failed";

                if (DueDate.Date < DateTime.Today)
                    return "Overdue";

                return "Due";
            }
        }
    }

    // 
    // STATUS → COLOUR CONVERTER
    // 

    /// <summary>
    /// Converts assessment status text into a coloured label.
    /// </summary>
    public class StatusToColourConverter : IValueConverter
    {
       
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string status = value?.ToString() ?? string.Empty;

            return status switch
            {
                "Passed" => new SolidColorBrush(Colors.Gold),
                "Failed" => new SolidColorBrush(Colors.DarkRed),
                "Due" => new SolidColorBrush(Colors.IndianRed),
                "Overdue" => new SolidColorBrush(Colors.DarkRed),
                _ => new SolidColorBrush(Colors.Gray)
            };
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
